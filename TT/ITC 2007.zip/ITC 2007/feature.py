class Feature():
	def __init__(self, feature_id=0):
		self.feature_id = feature_id
		self.rooms_list = []