class Room():
	def __init__(self, capacity=0, room_id=0):
		self.capacity = capacity
		self.room_id = room_id
		self.feature_list = []
