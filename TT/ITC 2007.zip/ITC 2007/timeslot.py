class Timeslot():
	def __init__(self, timeslot_id=0):
		self.timeslot_id = timeslot_id
		self.possible_events = []