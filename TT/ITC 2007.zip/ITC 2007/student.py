class Student():
	def __init__(self, student_id=0):
		self.event_list = []
		self.student_id = student_id

